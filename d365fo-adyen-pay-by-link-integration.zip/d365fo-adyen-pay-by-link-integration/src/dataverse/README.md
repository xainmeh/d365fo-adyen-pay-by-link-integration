# Dataverse Components

This folder will contain Dataverse table definitions, choice definitions, and solution notes.

## Planned Tables

1. isw_adyenpaymentrequest.
2. isw_adyenpaymentresponse.
3. isw_adyenpaymenteventlog.

## Planned Choices

1. isw_paymentstatus.
2. isw_webhookprocessingstatus.

## Notes

Dataverse is used as an integration tracking layer. It should not store raw card details.
