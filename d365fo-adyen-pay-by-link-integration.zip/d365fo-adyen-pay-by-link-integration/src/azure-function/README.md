# Azure Function Components

This folder will contain an optional Azure Function based implementation for API orchestration and webhook handling.

## Planned Functions

1. CreatePaymentLink.
2. ProcessAdyenWebhook.
3. UpdateD365FOPaymentStatus.

## Notes

Azure Functions can be used instead of Power Automate where more control, security, or scalability is required.
