# X++ Components

This folder will contain proposed D365FO X++ components.

## Planned Objects

| Object | Type | Purpose |
| --- | --- | --- |
| ISWAdyenPayByLinkParameters | Table | Stores configuration and business rules. |
| ISWAdyenPaymentRequest | Table | Stores payment request records. |
| ISWAdyenPaymentLog | Table | Stores integration logs. |
| ISWAdyenPaymentStatus | Enum | Stores payment status values. |
| ISWAdyenSalesConfirm_Extension | Class extension | Triggers payment request creation after sales order confirmation. |
| ISWAdyenPayByLinkService | Class | Prepares payment link request data. |
| ISWAdyenPaymentUpdateService | Class | Updates payment status from integration layer. |
| ISWAdyenPaymentRequestEntity | Data entity | Exposes payment requests externally. |
| ISWAdyenPaymentResponseEntity | Data entity | Receives payment response updates. |

## Notes

This folder currently contains design placeholders. Actual X++ source files will be added in future releases.
