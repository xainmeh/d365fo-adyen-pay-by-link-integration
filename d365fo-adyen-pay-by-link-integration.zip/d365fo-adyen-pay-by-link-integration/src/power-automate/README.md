# Power Automate Components

This folder will contain Power Automate flow documentation and exported samples where applicable.

## Planned Flows

1. Create Adyen payment link.
2. Send payment link to customer.
3. Process Adyen webhook response.
4. Update D365FO payment request status.

## Notes

Actual Power Automate solution exports are not included yet.
